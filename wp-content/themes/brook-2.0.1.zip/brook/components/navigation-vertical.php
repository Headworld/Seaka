<div id="page-navigation" <?php Brook::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Brook::menu_primary( array(
			'menu_class' => 'menu__container sm sm-simple sm-vertical',
		) ); ?>
	</nav>
</div>
