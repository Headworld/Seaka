<div id="page-navigation" <?php Brook::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Brook::menu_primary(); ?>
	</nav>
</div>
