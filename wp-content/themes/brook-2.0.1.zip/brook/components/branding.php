<div <?php Brook::branding_class(); ?>>
	<div class="branding__logo">
		<?php Brook::branding_logo(); ?>
	</div>
</div>
