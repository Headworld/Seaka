<div class="post-overlay primary-background-color"></div>
<div class="post-overlay-content">
	<div class="post-overlay-content-inner">
		<div class="post-overlay-info">
			<h3 class="post-overlay-title"><?php the_title(); ?></h3>
		</div>
	</div>
</div>
