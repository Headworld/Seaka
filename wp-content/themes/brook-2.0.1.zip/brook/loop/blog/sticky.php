<?php if ( is_sticky() ): ?>
	<div class="post-sticky">
		<span class="fa fa-bolt meta-icon"></span>
		<?php esc_html_e( 'Sticky', 'brook' ); ?>
	</div>
<?php endif;
