<div class="post-read-more">
	<a href="<?php the_permalink(); ?>" class="tm-button tm-button-primary style-flat">
		<span class="btn-text">
			<?php esc_html_e( 'Read More', 'brook' ); ?>
		</span>
	</a>
</div>
