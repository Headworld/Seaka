<div class="post-author">
	<?php echo esc_html__( 'by', 'brook' ) . ' ' . get_the_author(); ?>
</div>
