<div class="post-excerpt">
	<?php Brook_Templates::excerpt( array(
		'limit' => 100,
		'type'  => 'character',
	) ); ?>
</div>
