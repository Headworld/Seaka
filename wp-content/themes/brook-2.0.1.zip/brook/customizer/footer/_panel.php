<?php
$panel    = 'footer';
$priority = 1;

Brook_Kirki::add_section( 'footer', array(
	'title'    => esc_html__( 'General', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_01', array(
	'title'    => esc_html__( 'Style 01', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_02', array(
	'title'    => esc_html__( 'Style 02', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_03', array(
	'title'    => esc_html__( 'Style 03', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_04', array(
	'title'    => esc_html__( 'Style 04', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_05', array(
	'title'    => esc_html__( 'Style 05', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Brook_Kirki::add_section( 'footer_06', array(
	'title'    => esc_html__( 'Style 06', 'brook' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );
